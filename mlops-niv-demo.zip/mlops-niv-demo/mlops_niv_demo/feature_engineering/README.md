# Feature Engineering
To set up the feature engineering job via scheduled Databricks workflow, please refer to [mlops_niv_demo/resources/README.md](../resources/README.md)

For additional details on using the feature store, please refer to [mlops_niv_demo/docs/ml-developer-guide-fs.md](../../docs/ml-developer-guide-fs.md).