# Model Validation
To enable model validation as part of scheduled databricks workflow, please refer to [mlops_niv_demo/resources/README.md](../resources/README.md)